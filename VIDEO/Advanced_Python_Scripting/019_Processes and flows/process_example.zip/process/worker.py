import time

for i in range(11):
    time.sleep(0.2)
    print 'Progress: ', i*10