import socket
PORT = 12345
IP = socket.gethostbyname(socket.gethostname())
UINT32 = 4